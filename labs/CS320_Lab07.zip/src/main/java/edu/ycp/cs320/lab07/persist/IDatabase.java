package edu.ycp.cs320.lab07.persist;

import java.util.List;

import edu.ycp.cs320.lab07.model.Author;
import edu.ycp.cs320.lab07.model.Book;
import edu.ycp.cs320.lab07.model.Pair;

public interface IDatabase {
	public List<Pair<Author, Book>> findAuthorAndBookByTitle(String title);
}
