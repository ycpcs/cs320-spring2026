package edu.ycp.cs320.FunctorSample;

import java.util.Comparator;

public class StringComparatorCaseInsensitive implements Comparator<String> {

	@Override
	public int compare(String s1, String s2) {
		return s1.toLowerCase().compareTo(s2.toLowerCase());
	}

}
