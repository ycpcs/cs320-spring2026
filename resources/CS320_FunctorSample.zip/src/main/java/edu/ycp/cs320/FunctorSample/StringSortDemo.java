package edu.ycp.cs320.FunctorSample;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class StringSortDemo {

	public static void main(String[] args) {
		Scanner keyboard = new Scanner(System.in);
		System.out.println("Sort by:");
		System.out.println("1: Default (ascending case sensitive)");
		System.out.println("2: Descending (case sensitive)");
		System.out.println("3: Ascending (case insensitive)");
		System.out.println("4: Ascending (skip leading article)");
		
		int sortChoice = keyboard.nextInt();
		
		ArrayList<String> origTitles = new ArrayList<String>();
		populateTitles(origTitles);
		
		if(sortChoice == 1) {
			// Standard sort
			Collections.sort(origTitles);
		} else if (sortChoice == 2) {
			// Descending sort
			Collections.sort(origTitles,new StringComparatorDescending());
		} else if (sortChoice == 3) {
			// Case insensitive sort
			Collections.sort(origTitles, new StringComparatorCaseInsensitive());
		} else if (sortChoice == 4) {
			// Sort neglecting leading articles
			ArrayList<String> skipWords = new ArrayList<String>();
			skipWords.add("A");
			skipWords.add("An");
			skipWords.add("The");
			Collections.sort(origTitles, new StringComparatorSkipFirst(skipWords));
		}

		// Print sorted array
		for (String s : origTitles) {
			System.out.println(s);
		}
		
		keyboard.close();
	}
	
	private static void populateTitles(ArrayList<String> titles) {
		titles.add("A Brief History of Time");
		titles.add("The Universe in a Nutshell");
		titles.add("A Briefer History of Time");
		titles.add("The Grand Design");
		titles.add("The unexpected journey");
		titles.add("The Hitchhiker’s Guide to the Galaxy");
		titles.add("The Restaurant at the End of the Universe");
		titles.add("Life, The Universe and Everything");
		titles.add("So Long, and Thanks for all the Fish");
	}
}
