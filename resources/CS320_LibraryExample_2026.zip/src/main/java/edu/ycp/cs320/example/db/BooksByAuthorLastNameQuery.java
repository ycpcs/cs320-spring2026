package edu.ycp.cs320.example.db;

import java.util.List;
import java.util.Scanner;

import edu.ycp.cs320.example.db.model.Author;
import edu.ycp.cs320.example.db.model.Book;
import edu.ycp.cs320.example.db.model.Pair;
import edu.ycp.cs320.example.db.persist.DatabaseProvider;
import edu.ycp.cs320.example.db.persist.IDatabase;

public class BooksByAuthorLastNameQuery {
	public static void main(String[] args) throws Exception {
		Scanner keyboard = new Scanner(System.in);

		// Create the default IDatabase instance
		InitDatabase.init(keyboard);
		
		System.out.print("Enter an author's last name: ");
		String lastname = keyboard.nextLine();
		
		// get the DB instance and execute transaction
		IDatabase db = DatabaseProvider.getInstance();
		List<Pair<Author, Book>> authorBookList = db.findAuthorAndBooksByAuthorLastName(lastname);
		
		// check if anything was returned and output the list
		if (authorBookList.isEmpty()) {
			System.out.println("No authors found with lastname <" + lastname + ">");
		}
		else {
			for (Pair<Author, Book> authorBook : authorBookList) {
				Author author = authorBook.getLeft();
				Book book = authorBook.getRight();
				System.out.println(author.getLastname() + "," + author.getFirstname() + "," + book.getTitle() + "," + book.getIsbn() + "," + book.getPublished());
			}
		}
	}
}
