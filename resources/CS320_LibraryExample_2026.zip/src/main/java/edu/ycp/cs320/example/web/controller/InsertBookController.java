package edu.ycp.cs320.example.web.controller;

import edu.ycp.cs320.example.db.model.Author;
import edu.ycp.cs320.example.db.model.Book;
import edu.ycp.cs320.example.db.persist.DatabaseProvider;
import edu.ycp.cs320.example.db.persist.DerbyDatabase;
import edu.ycp.cs320.example.db.persist.IDatabase;

public class InsertBookController {

	private IDatabase db = null;

	public InsertBookController() {
		
		// creating DB instance here
		DatabaseProvider.setInstance(new DerbyDatabase());
		db = DatabaseProvider.getInstance();		
	}

	public boolean insertBookIntoLibrary(String title, String isbn, int published, String lastName, String firstName) {
		Author author = new Author();
		author.setFirstname(firstName);
		author.setLastname(lastName);

		Book book = new Book();
		book.setTitle(title);
		book.setIsbn(isbn);
		book.setPublished(published);

		// insert new book (and possibly new author) into DB
		Integer book_id = db.insertNewBookWithAuthor(author, book);

		// check if the insertion succeeded
		if (book_id > 0)
		{
			System.out.println("New book (ID: " + book_id + ") successfully added to Books table: <" + title + ">");
			
			return true;
		}
		else
		{
			System.out.println("Failed to insert new book (ID: " + book_id + ") into Books table: <" + title + ">");
			
			return false;
		}
	}
}
