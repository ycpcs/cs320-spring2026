package edu.ycp.cs320.example.db;

import java.util.List;
import java.util.Scanner;

import edu.ycp.cs320.example.db.model.Author;
import edu.ycp.cs320.example.db.model.Book;
import edu.ycp.cs320.example.db.model.Pair;
import edu.ycp.cs320.example.db.persist.DatabaseProvider;
import edu.ycp.cs320.example.db.persist.IDatabase;

public class InsertNewBookWithAuthor {
	public static void main(String[] args) throws Exception {
		Scanner keyboard = new Scanner(System.in);

		// Create the default IDatabase instance
		InitDatabase.init(keyboard);
		
		// prompt user for info
		System.out.print("Author's first name: ");
		String firstname = keyboard.nextLine();
		System.out.print("Author's last name: ");
		String lastname = keyboard.nextLine();
		System.out.print("Book's title: ");
		String title = keyboard.nextLine();
		System.out.print("Book's ISBN: ");
		String isbn = keyboard.nextLine();
		System.out.print("Book's published year: ");
		Integer published = keyboard.nextInt();
		
		Author author = new Author();
		author.setFirstname(firstname);
		author.setLastname(lastname);
		
		Book book = new Book();
		book.setTitle(title);
		book.setIsbn(isbn);
		book.setPublished(published);
		
		// get the DB instance and execute transaction
		IDatabase db = DatabaseProvider.getInstance();
		Integer book_id = db.insertNewBookWithAuthor(author, book);
		
		// check if anything was returned and output the list
		if (book_id == -1) {
			System.out.println("Failed to insert new book");
		}
		else {
			System.out.println("New book inserted successfully");
		}
		
		// Display authors books
		List<Pair<Author, Book>> authorBookList = db.findAuthorAndBooksByAuthorLastName(lastname);
		
		// check if anything was returned and output the list
		if (authorBookList.isEmpty()) {
			System.out.println("No authors found with lastname <" + lastname + ">");
		}
		else {
			for (Pair<Author, Book> authorBook : authorBookList) {
				Author bookAuthor = authorBook.getLeft();
				Book bookBook = authorBook.getRight();
				System.out.println(author.getLastname() + "," + bookAuthor.getFirstname() + "," + bookBook.getTitle() + "," + bookBook.getIsbn() + "," + bookBook.getPublished());
			}
		}

	}
}
